# 维护说明

## 如何修改规则

建议直接修改 `rules/` 目录下的 Markdown 文件。每次修改时注意：

- 保留步骤编号。
- 保留负责人边界。
- 保留交接语。
- 不要把多个负责人职责混在一起。

## 命名规范

推荐文件名：

```text
01-topic-positioning.md
02-story-outline.md
03-character-rules.md
04-chapter-outline.md
05-draft-writing.md
06-editor-review.md
07-final-assembly.md
08-final-quality-check.md
09-final-repair.md
```

## 版本管理建议

如果发布到 GitHub，建议：

- 每次修改规则都写清 commit message。
- 大改规则时打 tag，例如 `v1.1.0`。
- 在 README 里写清适用范围。
- 不要提交 `.env`、API Key、数据库文件、用户数据、日志文件。

## 建议的 GitHub `.gitignore`

```gitignore
.env
node_modules/
data/
logs/
*.docx
```

如果你希望保留原始 Word 文件，可以移除 `*.docx`，但公开前应确认里面没有私密信息。
